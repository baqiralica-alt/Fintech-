# LedgerAPI

A lightweight invoicing, receivables, and expense-tracking **API** for service businesses — WhatsApp API
resellers, dev agencies, subscription businesses, or any other service you sell. Built to work like a
minimal, focused slice of Xero/QuickBooks: customers, invoices, payments, expenses, and the reports that
actually matter (aged receivables, revenue by category, profit & loss) — accessible entirely through a REST
API with auto-generated interactive docs.

This is a real, working, tested backend — not a mockup. Every endpoint below was exercised end-to-end
(register → login → create customer → create invoice → send it → record a partial payment → confirm the
invoice status updates automatically → pull the aged receivables report) before this was handed to you.

## Why this exists

Over this conversation we built the Excel version of this — Stripe/Xero/Meta dashboards, aged receivables,
IFRS/GAAP statements, a Meta invoice discount-recovery parser. This is that same logic, as a real backend
you (or your customers) can integrate with, instead of a spreadsheet someone has to keep updating by hand.

## What's included

- **Multi-tenant**: each business (Organization) gets its own API key, its own data, fully isolated.
- **Two auth modes**: JWT Bearer token (for a logged-in dashboard user) OR an `X-API-Key` header (for
  server-to-server integrations — same pattern Stripe uses).
- **Customers, Service Catalog, Invoices (with line items), Payments, Expenses.**
- **Auto status transitions**: recording a payment automatically moves an invoice from `sent` →
  `partially_paid` → `paid`. No manual bookkeeping.
- **Reports**: Aged Receivables (Current/1-30/31-60/61-90/90+, mirrors the Excel logic exactly), Revenue by
  Category, Profit & Loss.
- **Interactive API docs** at `/docs` (Swagger UI) and `/redoc` — auto-generated from the code, always
  in sync, and directly usable to test every endpoint from a browser.
- **OpenAPI schema** included (`openapi_schema.json`) — import it into Postman, Insomnia, or use it to
  auto-generate a client SDK in any language.

## Quick start (local)

```bash
cd saas_api
pip install -r requirements.txt
cp .env.example .env        # edit JWT_SECRET_KEY before going to production
uvicorn app.main:app --reload
```

Open **http://localhost:8000/docs** — that's a full interactive API console, no extra setup.

## Authentication

**1. Register your business** (one-time):
```bash
curl -X POST http://localhost:8000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"org_name":"Alice Labs Pte Ltd","admin_email":"owner@alicelabs.com","admin_password":"yourpassword"}'
```
The response includes your `api_key` (starts with `lk_live_...`) — save it. Use it in the `X-API-Key`
header for every other request, exactly like a Stripe secret key.

**2. Or log in as a user** to get a short-lived JWT instead (useful for a web dashboard):
```bash
curl -X POST http://localhost:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"owner@alicelabs.com","password":"yourpassword"}'
```
Then send `Authorization: Bearer <token>` on subsequent requests.

## Example: full invoice lifecycle

```bash
API_KEY="lk_live_..."

# Create a customer
curl -X POST http://localhost:8000/customers -H "X-API-Key: $API_KEY" -H "Content-Type: application/json" \
  -d '{"name":"Jarir Bookstore","email":"ap@jarir.com","country":"Saudi Arabia","currency":"USD"}'

# Add a service to your catalog (category can be anything — WhatsApp, Subscription, Development, or your own)
curl -X POST http://localhost:8000/service-items -H "X-API-Key: $API_KEY" -H "Content-Type: application/json" \
  -d '{"name":"WhatsApp API Usage","category":"WhatsApp","default_price":500}'

# Create an invoice
curl -X POST http://localhost:8000/invoices -H "X-API-Key: $API_KEY" -H "Content-Type: application/json" \
  -d '{"customer_id":"<id>","invoice_number":"INV-1001","due_date":"2026-08-15T00:00:00",
       "lines":[{"service_item_id":"<id>","description":"WhatsApp API - July","quantity":1,"unit_price":1000}]}'

# Send it (draft -> sent)
curl -X POST http://localhost:8000/invoices/<invoice_id>/send -H "X-API-Key: $API_KEY"

# Record a payment (auto-updates status to partially_paid or paid)
curl -X POST http://localhost:8000/payments -H "X-API-Key: $API_KEY" -H "Content-Type: application/json" \
  -d '{"invoice_id":"<invoice_id>","amount":600,"method":"bank_transfer","reference":"TXN123"}'

# Pull the aged receivables report
curl http://localhost:8000/reports/aged-receivables -H "X-API-Key: $API_KEY"
```

## Full endpoint reference

| Method | Path | Purpose |
|---|---|---|
| POST | `/auth/register` | Create a new organization + admin user, get an API key |
| POST | `/auth/login` | Log in, get a JWT |
| POST | `/customers` | Create a customer |
| GET | `/customers` | List customers |
| GET/PUT/DELETE | `/customers/{id}` | Get, update, or delete a customer |
| POST | `/service-items` | Add a billable service to your catalog |
| GET | `/service-items` | List your service catalog |
| DELETE | `/service-items/{id}` | Remove a service |
| POST | `/invoices` | Create an invoice with line items |
| GET | `/invoices` | List invoices (filter by `status` or `customer_id`) |
| GET | `/invoices/{id}` | Get one invoice |
| POST | `/invoices/{id}/send` | Mark draft → sent |
| POST | `/invoices/{id}/void` | Void an invoice (blocked if fully paid) |
| DELETE | `/invoices/{id}` | Delete a draft invoice |
| POST | `/payments` | Record a payment against an invoice |
| GET | `/payments` | List payments (filter by `invoice_id`) |
| POST | `/expenses` | Log an expense |
| GET | `/expenses` | List expenses |
| DELETE | `/expenses/{id}` | Delete an expense |
| GET | `/reports/aged-receivables` | Current/1-30/31-60/61-90/90+ buckets per customer |
| GET | `/reports/revenue-by-category` | Revenue totals grouped by service category |
| GET | `/reports/profit-and-loss` | Revenue − expenses for a date range |

Full request/response schemas, with the ability to try every endpoint live, are at `/docs`.

## Deploying it for real

This runs anywhere Python runs. The fastest free/cheap options:

- **Railway** or **Render**: connect this repo, set `DATABASE_URL` to a managed Postgres instance (both
  offer one free), set `JWT_SECRET_KEY`, deploy. Takes about 10 minutes.
- **Fly.io**: `fly launch` in this folder, add a Postgres app, set the same two env vars.

Switching from SQLite to Postgres needs zero code changes — just set `DATABASE_URL` to your Postgres
connection string; SQLAlchemy handles the rest.

## What this deliberately does NOT include (be honest about scope)

- **No frontend.** This is an API only — pair it with a simple React/Next.js dashboard, or point Retool /
  Bubble / a no-code tool at it if you want a UI fast without building one from scratch.
- **No payment collection.** It *records* payments; it doesn't *collect* them. Wire it up to Stripe/Wise
  webhooks to auto-record payments instead of entering them manually — the `/payments` endpoint is ready
  to receive that.
- **No recurring invoice auto-generation yet.** The `recurring` and `recurring_frequency` fields exist on
  the Invoice model as a foundation, but nothing currently reads them to generate the next invoice
  automatically — that's the natural next feature to build (a daily cron job that checks due dates).
- **No multi-currency FX conversion.** Amounts are stored and reported in their original currency, same
  approach used throughout the Excel work this session — deliberately no invented conversion rates.
- **Single-region, single-instance.** Fine for early customers; add connection pooling and a proper
  Postgres instance before real scale.

## Files in this package

```
saas_api/
├── app/
│   ├── main.py              FastAPI app entry point
│   ├── database.py          DB connection (SQLite by default, Postgres via env var)
│   ├── models.py            SQLAlchemy models (the data model)
│   ├── schemas.py           Pydantic request/response validation
│   ├── auth.py               JWT + API key authentication
│   └── routers/
│       ├── auth_routes.py
│       ├── customers.py
│       ├── service_items.py
│       ├── invoices.py
│       ├── payments.py
│       ├── expenses.py
│       └── reports.py
├── requirements.txt
├── .env.example
├── openapi_schema.json      Full API spec — import into Postman/Insomnia
└── README.md                This file
```
