import enum
import secrets
import uuid
from datetime import datetime

from sqlalchemy import (Column, String, Float, Integer, DateTime, ForeignKey,
                         Enum, Text, Boolean)
from sqlalchemy.orm import relationship

from .database import Base


def gen_id():
    return str(uuid.uuid4())


def gen_api_key():
    return "lk_live_" + secrets.token_urlsafe(32)


class InvoiceStatus(str, enum.Enum):
    draft = "draft"
    sent = "sent"
    paid = "paid"
    partially_paid = "partially_paid"
    overdue = "overdue"
    void = "void"
    uncollectible = "uncollectible"


class Organization(Base):
    """A tenant / business account — every other record belongs to one org."""
    __tablename__ = "organizations"
    id = Column(String, primary_key=True, default=gen_id)
    name = Column(String, nullable=False)
    api_key = Column(String, unique=True, index=True, default=gen_api_key)
    default_currency = Column(String, default="USD")
    created_at = Column(DateTime, default=datetime.utcnow)

    users = relationship("User", back_populates="org")
    customers = relationship("Customer", back_populates="org")
    service_items = relationship("ServiceItem", back_populates="org")
    invoices = relationship("Invoice", back_populates="org")
    expenses = relationship("Expense", back_populates="org")


class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=gen_id)
    org_id = Column(String, ForeignKey("organizations.id"), nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String)
    role = Column(String, default="owner")  # owner, accountant, viewer
    created_at = Column(DateTime, default=datetime.utcnow)

    org = relationship("Organization", back_populates="users")


class Customer(Base):
    __tablename__ = "customers"
    id = Column(String, primary_key=True, default=gen_id)
    org_id = Column(String, ForeignKey("organizations.id"), nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, index=True)
    phone = Column(String)
    country = Column(String)
    currency = Column(String, default="USD")
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    org = relationship("Organization", back_populates="customers")
    invoices = relationship("Invoice", back_populates="customer")


class ServiceItem(Base):
    """Catalog of billable services — e.g. WhatsApp API, Subscription, Development, or anything else."""
    __tablename__ = "service_items"
    id = Column(String, primary_key=True, default=gen_id)
    org_id = Column(String, ForeignKey("organizations.id"), nullable=False)
    name = Column(String, nullable=False)
    description = Column(Text)
    category = Column(String, default="Other Services")  # revenue category, fully custom text
    default_price = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)

    org = relationship("Organization", back_populates="service_items")


class Invoice(Base):
    __tablename__ = "invoices"
    id = Column(String, primary_key=True, default=gen_id)
    org_id = Column(String, ForeignKey("organizations.id"), nullable=False)
    customer_id = Column(String, ForeignKey("customers.id"), nullable=False)
    invoice_number = Column(String, index=True)
    issue_date = Column(DateTime, default=datetime.utcnow)
    due_date = Column(DateTime)
    currency = Column(String, default="USD")
    status = Column(Enum(InvoiceStatus), default=InvoiceStatus.draft)
    subtotal = Column(Float, default=0.0)
    tax_total = Column(Float, default=0.0)
    total = Column(Float, default=0.0)
    amount_paid = Column(Float, default=0.0)
    notes = Column(Text)
    recurring = Column(Boolean, default=False)
    recurring_frequency = Column(String, nullable=True)  # monthly / quarterly / annual
    created_at = Column(DateTime, default=datetime.utcnow)

    org = relationship("Organization", back_populates="invoices")
    customer = relationship("Customer", back_populates="invoices")
    lines = relationship("InvoiceLine", back_populates="invoice", cascade="all, delete-orphan")
    payments = relationship("Payment", back_populates="invoice", cascade="all, delete-orphan")

    @property
    def amount_due(self):
        if self.status in (InvoiceStatus.void, InvoiceStatus.uncollectible):
            return 0.0
        return round(self.total - self.amount_paid, 2)


class InvoiceLine(Base):
    __tablename__ = "invoice_lines"
    id = Column(String, primary_key=True, default=gen_id)
    invoice_id = Column(String, ForeignKey("invoices.id"), nullable=False)
    service_item_id = Column(String, ForeignKey("service_items.id"), nullable=True)
    description = Column(String, nullable=False)
    quantity = Column(Float, default=1.0)
    unit_price = Column(Float, default=0.0)
    amount = Column(Float, default=0.0)

    invoice = relationship("Invoice", back_populates="lines")


class Payment(Base):
    __tablename__ = "payments"
    id = Column(String, primary_key=True, default=gen_id)
    org_id = Column(String, ForeignKey("organizations.id"), nullable=False)
    invoice_id = Column(String, ForeignKey("invoices.id"), nullable=False)
    amount = Column(Float, nullable=False)
    payment_date = Column(DateTime, default=datetime.utcnow)
    method = Column(String, default="bank_transfer")  # bank_transfer, card, cash, other
    reference = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    invoice = relationship("Invoice", back_populates="payments")


class Expense(Base):
    __tablename__ = "expenses"
    id = Column(String, primary_key=True, default=gen_id)
    org_id = Column(String, ForeignKey("organizations.id"), nullable=False)
    vendor_name = Column(String, nullable=False)
    category = Column(String, default="Uncategorized")
    amount = Column(Float, nullable=False)
    currency = Column(String, default="USD")
    expense_date = Column(DateTime, default=datetime.utcnow)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    org = relationship("Organization", back_populates="expenses")
