from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db

router = APIRouter(prefix="/service-items", tags=["Service Catalog"])


@router.post("", response_model=schemas.ServiceItemOut)
def create_service_item(payload: schemas.ServiceItemCreate, org: models.Organization = Depends(auth.get_current_org),
                         db: Session = Depends(get_db)):
    item = models.ServiceItem(org_id=org.id, **payload.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@router.get("", response_model=List[schemas.ServiceItemOut])
def list_service_items(org: models.Organization = Depends(auth.get_current_org), db: Session = Depends(get_db)):
    return db.query(models.ServiceItem).filter(models.ServiceItem.org_id == org.id).all()


@router.delete("/{item_id}")
def delete_service_item(item_id: str, org: models.Organization = Depends(auth.get_current_org),
                         db: Session = Depends(get_db)):
    item = db.query(models.ServiceItem).filter(models.ServiceItem.id == item_id,
                                                 models.ServiceItem.org_id == org.id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Service item not found")
    db.delete(item)
    db.commit()
    return {"deleted": True}
