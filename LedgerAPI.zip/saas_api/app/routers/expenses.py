from datetime import datetime
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db

router = APIRouter(prefix="/expenses", tags=["Expenses"])


@router.post("", response_model=schemas.ExpenseOut)
def create_expense(payload: schemas.ExpenseCreate, org: models.Organization = Depends(auth.get_current_org),
                    db: Session = Depends(get_db)):
    expense = models.Expense(
        org_id=org.id,
        vendor_name=payload.vendor_name,
        category=payload.category,
        amount=payload.amount,
        currency=payload.currency,
        expense_date=payload.expense_date or datetime.utcnow(),
        description=payload.description,
    )
    db.add(expense)
    db.commit()
    db.refresh(expense)
    return expense


@router.get("", response_model=List[schemas.ExpenseOut])
def list_expenses(org: models.Organization = Depends(auth.get_current_org), db: Session = Depends(get_db)):
    return db.query(models.Expense).filter(models.Expense.org_id == org.id).all()


@router.delete("/{expense_id}")
def delete_expense(expense_id: str, org: models.Organization = Depends(auth.get_current_org),
                    db: Session = Depends(get_db)):
    e = db.query(models.Expense).filter(models.Expense.id == expense_id, models.Expense.org_id == org.id).first()
    if not e:
        raise HTTPException(status_code=404, detail="Expense not found")
    db.delete(e)
    db.commit()
    return {"deleted": True}
