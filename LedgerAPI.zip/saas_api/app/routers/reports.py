from datetime import datetime
from typing import List, Optional
from collections import defaultdict

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db
from ..models import InvoiceStatus

router = APIRouter(prefix="/reports", tags=["Reports"])


@router.get("/aged-receivables", response_model=List[schemas.AgedReceivableRow])
def aged_receivables(as_of: Optional[datetime] = Query(default=None, description="Defaults to now"),
                      org: models.Organization = Depends(auth.get_current_org), db: Session = Depends(get_db)):
    """
    Same bucket logic used throughout the Excel workbooks this session:
    Current / 1-30 / 31-60 / 61-90 / 90+ days overdue, based on due date.
    Void and uncollectible invoices are excluded entirely (they are not real receivables).
    """
    as_of = as_of or datetime.utcnow()
    invoices = (
        db.query(models.Invoice)
        .filter(
            models.Invoice.org_id == org.id,
            models.Invoice.status.in_([InvoiceStatus.sent, InvoiceStatus.partially_paid, InvoiceStatus.overdue]),
        )
        .all()
    )

    buckets = defaultdict(lambda: {"current": 0.0, "d1_30": 0.0, "d31_60": 0.0, "d61_90": 0.0, "d90p": 0.0})
    customer_names = {}
    customer_currency = {}

    for inv in invoices:
        due = inv.due_date or inv.issue_date
        days_overdue = (as_of - due).days if due else 0
        amt = inv.amount_due
        if amt <= 0:
            continue
        key = (inv.customer_id, inv.currency)
        customer_names[inv.customer_id] = inv.customer.name if inv.customer else "Unknown"
        customer_currency[key] = inv.currency
        if days_overdue <= 0:
            buckets[key]["current"] += amt
        elif days_overdue <= 30:
            buckets[key]["d1_30"] += amt
        elif days_overdue <= 60:
            buckets[key]["d31_60"] += amt
        elif days_overdue <= 90:
            buckets[key]["d61_90"] += amt
        else:
            buckets[key]["d90p"] += amt

    rows = []
    for (cust_id, currency), b in buckets.items():
        total = round(sum(b.values()), 2)
        rows.append(schemas.AgedReceivableRow(
            customer_id=cust_id,
            customer_name=customer_names.get(cust_id, "Unknown"),
            currency=currency,
            current=round(b["current"], 2),
            days_1_30=round(b["d1_30"], 2),
            days_31_60=round(b["d31_60"], 2),
            days_61_90=round(b["d61_90"], 2),
            days_90_plus=round(b["d90p"], 2),
            total=total,
        ))
    return sorted(rows, key=lambda r: -r.total)


@router.get("/revenue-by-category", response_model=List[schemas.RevenueByCategoryRow])
def revenue_by_category(period_start: Optional[datetime] = None, period_end: Optional[datetime] = None,
                         org: models.Organization = Depends(auth.get_current_org), db: Session = Depends(get_db)):
    """Sums invoice line amounts by the service item's category (WhatsApp / Subscription / Development /
    Other Services / anything custom you define in the service catalog) — same idea as the Assumptions
    keyword map in the Excel workbook, but driven by an explicit category field instead of text matching."""
    q = db.query(models.InvoiceLine).join(models.Invoice).filter(
        models.Invoice.org_id == org.id,
        models.Invoice.status != InvoiceStatus.void,
        models.Invoice.status != InvoiceStatus.draft,
    )
    if period_start:
        q = q.filter(models.Invoice.issue_date >= period_start)
    if period_end:
        q = q.filter(models.Invoice.issue_date <= period_end)

    totals = defaultdict(float)
    for line in q.all():
        category = "Other Services"
        if line.service_item_id:
            item = db.query(models.ServiceItem).filter(models.ServiceItem.id == line.service_item_id).first()
            if item:
                category = item.category
        totals[category] += line.amount

    return [schemas.RevenueByCategoryRow(category=k, total=round(v, 2)) for k, v in
            sorted(totals.items(), key=lambda x: -x[1])]


@router.get("/profit-and-loss", response_model=schemas.ProfitLossReport)
def profit_and_loss(period_start: datetime, period_end: datetime,
                     org: models.Organization = Depends(auth.get_current_org), db: Session = Depends(get_db)):
    rev_rows = revenue_by_category(period_start, period_end, org, db)
    total_revenue = round(sum(r.total for r in rev_rows), 2)

    expenses = db.query(models.Expense).filter(
        models.Expense.org_id == org.id,
        models.Expense.expense_date >= period_start,
        models.Expense.expense_date <= period_end,
    ).all()
    total_expenses = round(sum(e.amount for e in expenses), 2)

    return schemas.ProfitLossReport(
        period_start=period_start,
        period_end=period_end,
        total_revenue=total_revenue,
        revenue_by_category=rev_rows,
        total_expenses=total_expenses,
        net_profit=round(total_revenue - total_expenses, 2),
    )
