from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db
from ..models import InvoiceStatus

router = APIRouter(prefix="/payments", tags=["Payments"])


@router.post("", response_model=schemas.PaymentOut)
def record_payment(payload: schemas.PaymentCreate, org: models.Organization = Depends(auth.get_current_org),
                    db: Session = Depends(get_db)):
    invoice = db.query(models.Invoice).filter(models.Invoice.id == payload.invoice_id,
                                                models.Invoice.org_id == org.id).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    if invoice.status in (InvoiceStatus.void, InvoiceStatus.draft):
        raise HTTPException(status_code=400,
                             detail=f"Cannot record a payment against an invoice with status '{invoice.status}'")

    payment = models.Payment(
        org_id=org.id,
        invoice_id=payload.invoice_id,
        amount=payload.amount,
        payment_date=payload.payment_date or datetime.utcnow(),
        method=payload.method,
        reference=payload.reference,
    )
    db.add(payment)

    # Recalculate invoice paid/status — this is the "net receivable" logic from the Excel work,
    # now automatic instead of manual.
    invoice.amount_paid = round(invoice.amount_paid + payload.amount, 2)
    if invoice.amount_paid >= invoice.total - 0.01:
        invoice.status = InvoiceStatus.paid
    elif invoice.amount_paid > 0:
        invoice.status = InvoiceStatus.partially_paid

    db.commit()
    db.refresh(payment)
    return payment


@router.get("", response_model=List[schemas.PaymentOut])
def list_payments(invoice_id: str = None, org: models.Organization = Depends(auth.get_current_org),
                   db: Session = Depends(get_db)):
    q = db.query(models.Payment).filter(models.Payment.org_id == org.id)
    if invoice_id:
        q = q.filter(models.Payment.invoice_id == invoice_id)
    return q.all()
