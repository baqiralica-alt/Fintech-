from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db

router = APIRouter(prefix="/customers", tags=["Customers"])


@router.post("", response_model=schemas.CustomerOut)
def create_customer(payload: schemas.CustomerCreate, org: models.Organization = Depends(auth.get_current_org),
                     db: Session = Depends(get_db)):
    customer = models.Customer(org_id=org.id, **payload.model_dump())
    db.add(customer)
    db.commit()
    db.refresh(customer)
    return customer


@router.get("", response_model=List[schemas.CustomerOut])
def list_customers(org: models.Organization = Depends(auth.get_current_org), db: Session = Depends(get_db)):
    return db.query(models.Customer).filter(models.Customer.org_id == org.id).all()


@router.get("/{customer_id}", response_model=schemas.CustomerOut)
def get_customer(customer_id: str, org: models.Organization = Depends(auth.get_current_org),
                  db: Session = Depends(get_db)):
    c = db.query(models.Customer).filter(models.Customer.id == customer_id, models.Customer.org_id == org.id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Customer not found")
    return c


@router.put("/{customer_id}", response_model=schemas.CustomerOut)
def update_customer(customer_id: str, payload: schemas.CustomerCreate,
                     org: models.Organization = Depends(auth.get_current_org), db: Session = Depends(get_db)):
    c = db.query(models.Customer).filter(models.Customer.id == customer_id, models.Customer.org_id == org.id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Customer not found")
    for k, v in payload.model_dump().items():
        setattr(c, k, v)
    db.commit()
    db.refresh(c)
    return c


@router.delete("/{customer_id}")
def delete_customer(customer_id: str, org: models.Organization = Depends(auth.get_current_org),
                     db: Session = Depends(get_db)):
    c = db.query(models.Customer).filter(models.Customer.id == customer_id, models.Customer.org_id == org.id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Customer not found")
    db.delete(c)
    db.commit()
    return {"deleted": True}
