from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=schemas.OrgOut)
def register(payload: schemas.OrgCreate, db: Session = Depends(get_db)):
    """Create a new organization (tenant) and its first admin user. Returns the org's API key —
    save it, it's shown only once here (though it can be rotated later via /orgs/rotate-key)."""
    existing = db.query(models.User).filter(models.User.email == payload.admin_email).first()
    if existing:
        raise HTTPException(status_code=400, detail="An account with this email already exists")

    org = models.Organization(name=payload.org_name)
    db.add(org)
    db.flush()

    user = models.User(
        org_id=org.id,
        email=payload.admin_email,
        hashed_password=auth.hash_password(payload.admin_password),
        full_name=payload.admin_full_name,
        role="owner",
    )
    db.add(user)
    db.commit()
    db.refresh(org)
    return org


@router.post("/login", response_model=schemas.Token)
def login(payload: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if not user or not auth.verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    token = auth.create_access_token({"sub": user.id, "org_id": user.org_id})
    return {"access_token": token, "token_type": "bearer"}
