from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload

from .. import models, schemas, auth
from ..database import get_db
from ..models import InvoiceStatus

router = APIRouter(prefix="/invoices", tags=["Invoices"])


def _recalc_totals(invoice: models.Invoice):
    subtotal = sum(line.amount for line in invoice.lines)
    invoice.subtotal = round(subtotal, 2)
    invoice.total = round(subtotal + invoice.tax_total, 2)


@router.post("", response_model=schemas.InvoiceOut)
def create_invoice(payload: schemas.InvoiceCreate, org: models.Organization = Depends(auth.get_current_org),
                    db: Session = Depends(get_db)):
    customer = db.query(models.Customer).filter(models.Customer.id == payload.customer_id,
                                                   models.Customer.org_id == org.id).first()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")

    invoice = models.Invoice(
        org_id=org.id,
        customer_id=payload.customer_id,
        invoice_number=payload.invoice_number,
        issue_date=payload.issue_date or datetime.utcnow(),
        due_date=payload.due_date,
        currency=payload.currency,
        tax_total=payload.tax_total,
        notes=payload.notes,
        recurring=payload.recurring,
        recurring_frequency=payload.recurring_frequency,
        status=InvoiceStatus.draft,
    )
    for line_in in payload.lines:
        amount = round(line_in.quantity * line_in.unit_price, 2)
        invoice.lines.append(models.InvoiceLine(
            service_item_id=line_in.service_item_id,
            description=line_in.description,
            quantity=line_in.quantity,
            unit_price=line_in.unit_price,
            amount=amount,
        ))
    _recalc_totals(invoice)
    db.add(invoice)
    db.commit()
    db.refresh(invoice)
    return invoice


@router.get("", response_model=List[schemas.InvoiceOut])
def list_invoices(status: Optional[InvoiceStatus] = None, customer_id: Optional[str] = None,
                   org: models.Organization = Depends(auth.get_current_org), db: Session = Depends(get_db)):
    q = db.query(models.Invoice).options(joinedload(models.Invoice.lines)).filter(models.Invoice.org_id == org.id)
    if status:
        q = q.filter(models.Invoice.status == status)
    if customer_id:
        q = q.filter(models.Invoice.customer_id == customer_id)
    return q.all()


@router.get("/{invoice_id}", response_model=schemas.InvoiceOut)
def get_invoice(invoice_id: str, org: models.Organization = Depends(auth.get_current_org),
                 db: Session = Depends(get_db)):
    inv = db.query(models.Invoice).options(joinedload(models.Invoice.lines)).filter(
        models.Invoice.id == invoice_id, models.Invoice.org_id == org.id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return inv


@router.post("/{invoice_id}/send", response_model=schemas.InvoiceOut)
def send_invoice(invoice_id: str, org: models.Organization = Depends(auth.get_current_org),
                  db: Session = Depends(get_db)):
    inv = db.query(models.Invoice).filter(models.Invoice.id == invoice_id, models.Invoice.org_id == org.id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    if inv.status != InvoiceStatus.draft:
        raise HTTPException(status_code=400, detail=f"Cannot send an invoice with status '{inv.status}'")
    inv.status = InvoiceStatus.sent
    db.commit()
    db.refresh(inv)
    return inv


@router.post("/{invoice_id}/void", response_model=schemas.InvoiceOut)
def void_invoice(invoice_id: str, org: models.Organization = Depends(auth.get_current_org),
                  db: Session = Depends(get_db)):
    inv = db.query(models.Invoice).filter(models.Invoice.id == invoice_id, models.Invoice.org_id == org.id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    if inv.status == InvoiceStatus.paid:
        raise HTTPException(status_code=400, detail="Cannot void a fully paid invoice — issue a credit note instead")
    inv.status = InvoiceStatus.void
    db.commit()
    db.refresh(inv)
    return inv


@router.delete("/{invoice_id}")
def delete_invoice(invoice_id: str, org: models.Organization = Depends(auth.get_current_org),
                    db: Session = Depends(get_db)):
    inv = db.query(models.Invoice).filter(models.Invoice.id == invoice_id, models.Invoice.org_id == org.id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    if inv.status != InvoiceStatus.draft:
        raise HTTPException(status_code=400, detail="Only draft invoices can be deleted — void it instead")
    db.delete(inv)
    db.commit()
    return {"deleted": True}
