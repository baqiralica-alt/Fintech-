from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import Base, engine
from .routers import auth_routes, customers, service_items, invoices, payments, expenses, reports

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="LedgerAPI",
    description=(
        "A lightweight invoicing, receivables, and expense-tracking API for service businesses — "
        "WhatsApp API resellers, dev agencies, subscription businesses, or any other service you sell. "
        "Multi-tenant: each organization gets its own API key. Authenticate with either a Bearer JWT "
        "(from /auth/login, for a logged-in dashboard user) or an X-API-Key header (for integrations)."
    ),
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this to your actual frontend domain(s) in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_routes.router)
app.include_router(customers.router)
app.include_router(service_items.router)
app.include_router(invoices.router)
app.include_router(payments.router)
app.include_router(expenses.router)
app.include_router(reports.router)


@app.get("/")
def root():
    return {
        "name": "LedgerAPI",
        "status": "ok",
        "docs": "/docs",
        "openapi_schema": "/openapi.json",
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
