from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, ConfigDict

from .models import InvoiceStatus


# ---------- Auth / Org ----------
class OrgCreate(BaseModel):
    org_name: str
    admin_email: EmailStr
    admin_password: str
    admin_full_name: Optional[str] = None


class OrgOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    api_key: str
    default_currency: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


# ---------- Customer ----------
class CustomerCreate(BaseModel):
    name: str
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    country: Optional[str] = None
    currency: str = "USD"
    notes: Optional[str] = None


class CustomerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    email: Optional[str]
    phone: Optional[str]
    country: Optional[str]
    currency: str
    notes: Optional[str]
    created_at: datetime


# ---------- Service Item ----------
class ServiceItemCreate(BaseModel):
    name: str
    description: Optional[str] = None
    category: str = "Other Services"
    default_price: float = 0.0


class ServiceItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    description: Optional[str]
    category: str
    default_price: float


# ---------- Invoice ----------
class InvoiceLineCreate(BaseModel):
    service_item_id: Optional[str] = None
    description: str
    quantity: float = 1.0
    unit_price: float = 0.0


class InvoiceLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    service_item_id: Optional[str]
    description: str
    quantity: float
    unit_price: float
    amount: float


class InvoiceCreate(BaseModel):
    customer_id: str
    invoice_number: Optional[str] = None
    issue_date: Optional[datetime] = None
    due_date: Optional[datetime] = None
    currency: str = "USD"
    tax_total: float = 0.0
    notes: Optional[str] = None
    recurring: bool = False
    recurring_frequency: Optional[str] = None
    lines: List[InvoiceLineCreate]


class InvoiceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    customer_id: str
    invoice_number: Optional[str]
    issue_date: datetime
    due_date: Optional[datetime]
    currency: str
    status: InvoiceStatus
    subtotal: float
    tax_total: float
    total: float
    amount_paid: float
    amount_due: float
    notes: Optional[str]
    recurring: bool
    recurring_frequency: Optional[str]
    lines: List[InvoiceLineOut] = []


# ---------- Payment ----------
class PaymentCreate(BaseModel):
    invoice_id: str
    amount: float
    payment_date: Optional[datetime] = None
    method: str = "bank_transfer"
    reference: Optional[str] = None


class PaymentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    invoice_id: str
    amount: float
    payment_date: datetime
    method: str
    reference: Optional[str]


# ---------- Expense ----------
class ExpenseCreate(BaseModel):
    vendor_name: str
    category: str = "Uncategorized"
    amount: float
    currency: str = "USD"
    expense_date: Optional[datetime] = None
    description: Optional[str] = None


class ExpenseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    vendor_name: str
    category: str
    amount: float
    currency: str
    expense_date: datetime
    description: Optional[str]


# ---------- Reports ----------
class AgedReceivableRow(BaseModel):
    customer_id: str
    customer_name: str
    currency: str
    current: float
    days_1_30: float
    days_31_60: float
    days_61_90: float
    days_90_plus: float
    total: float


class RevenueByCategoryRow(BaseModel):
    category: str
    total: float


class ProfitLossReport(BaseModel):
    period_start: datetime
    period_end: datetime
    total_revenue: float
    revenue_by_category: List[RevenueByCategoryRow]
    total_expenses: float
    net_profit: float
